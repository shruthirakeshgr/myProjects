package theBowlingGame;

public class TheGameScoreCounter {

	private int setOfKnockedDownPins[] = new int[21]; // 21 is number of maximum balls
	private int scorePerFrame[] = new int[10];// 10 is the number of frames in a game
	private int currentBall = 0;
	private int currentScore = 0;

	void noOfPinsKnockedDownForEachBall(int noOfPinsKnockedDown) //to store the pins for each ball
	{
		setOfKnockedDownPins[currentBall] = noOfPinsKnockedDown;
		currentBall++;
		if (currentBall % 2 != 0 && noOfPinsKnockedDown == 10 && currentBall < 19)// store 0 for 2nd ball in a frame if its a strike
		{
			setOfKnockedDownPins[currentBall] = 0;
			currentBall++;

		}

	}
	void emptyForNewGame( ) //to store the pins for each ball
	{   currentBall = 0;
	 currentScore = 0;
		  for (int rollIttrator = 0; rollIttrator < 21; rollIttrator++) {
				
			  setOfKnockedDownPins[rollIttrator] = 0;
			  }
		  
	}
	void displayScore() {
		System.out.println();
		System.out.println("Score for each ball:");
		for (int ballIndex = 0; ballIndex < 21; ballIndex++) {
			System.out.print(setOfKnockedDownPins[ballIndex] + "  ");
			if (ballIndex % 2 != 0)
				System.out.print(": ");
		}
		System.out.println();
		for (int frameIndex = 0; frameIndex < 10; frameIndex++) {
			System.out.print("   " + scorePerFrame[frameIndex] + " | ");
		}
		System.out.print(" :score for each frame ");
		System.out.println( );
		System.out.println("Total Score is: "+scorePerFrame[9]);
		System.out.println( );

	}

	void scoreForTheGame() {

		for (int frameIndexing = 0; frameIndexing < 10; frameIndexing++) {
			currentScore = gerScore(frameIndexing);
			scorePerFrame[frameIndexing] = currentScore;// storing score per frame for display purpose 

		}
	}

	private int gerScore(int frameIndexing) {
		int framesFirstBallScoreIndex = (frameIndexing * 2);// 2 balls is one
															// frame
		int frameScore = setOfKnockedDownPins[framesFirstBallScoreIndex]
				+ setOfKnockedDownPins[framesFirstBallScoreIndex + 1];
		int score = frameScore + currentScore;
		if (framesFirstBallScoreIndex < 18)  {
			if (setOfKnockedDownPins[framesFirstBallScoreIndex] == 10)// its a strike
				return getStrikeScore(frameIndexing, score);
			else {

				if (frameScore == 10)
					return getSpareScore(frameIndexing, score); // its a spare
				else
					return score;
			}
		}else{ // last frame has 3 balls sometimes
score = score + setOfKnockedDownPins[framesFirstBallScoreIndex + 2]; // adding the last extra ball score
return score;
} 
	}

	private int getSpareScore(int frameIndexing, int previousScore) { // spare score is current score + next frames 1st ball score
		frameIndexing++; // pointing to next frame
		int framesFirstBallScoreIndex = (frameIndexing * 2);
		int score = previousScore + setOfKnockedDownPins[framesFirstBallScoreIndex]; // adding the extra score for spare

		return score;
	}

	private int getStrikeScore(int frameIndexing, int previousScore) { // strike score is current score + next 2 balls score, i.e usually next frames score 
		frameIndexing++;
		int framesFirstBallScoreIndex = (frameIndexing * 2);
		int nextFrameTotalScore = setOfKnockedDownPins[framesFirstBallScoreIndex]
				+ setOfKnockedDownPins[framesFirstBallScoreIndex + 1];
		int score = previousScore;
		if (setOfKnockedDownPins[framesFirstBallScoreIndex] != 10)
			score = score + nextFrameTotalScore; 

		else if (frameIndexing < 10) { // if next frame is strike or spare, we need to add bonus points. 
			// frameIndexing++;
			framesFirstBallScoreIndex = (frameIndexing * 2);
			nextFrameTotalScore = setOfKnockedDownPins[framesFirstBallScoreIndex];
			score = score + 10 + nextFrameTotalScore;
		}

		else if (frameIndexing == 10) { // for 10th frame, its the last 2 balls score. 

			nextFrameTotalScore = setOfKnockedDownPins[framesFirstBallScoreIndex];
			score = score + 10 + nextFrameTotalScore;
		}

		return score;
	}

}
