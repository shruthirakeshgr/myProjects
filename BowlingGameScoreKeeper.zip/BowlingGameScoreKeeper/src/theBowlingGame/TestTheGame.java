package theBowlingGame;

public class TestTheGame {
	private static TheGameScoreCounter g = new TheGameScoreCounter();

	public static void main(String[] args) {

		worstGame();
		allAreOnes();
		atleastOneSpare();
		atleastOneStrike();
		thePerfectGame();
		theRandomGame();

	}

	public static void automaticRoll(int noOfBalls, int noOfPins) {
		for (int rollIttrator = 0; rollIttrator < noOfBalls; rollIttrator++) {

			g.noOfPinsKnockedDownForEachBall(noOfPins);
		}
	}

	public static void spareGenerator() {
		g.noOfPinsKnockedDownForEachBall(3);
		g.noOfPinsKnockedDownForEachBall(7);

	}

	public static void strikeGenerator() {
		g.noOfPinsKnockedDownForEachBall(10);
	}

	public static void worstGame() {
		g.emptyForNewGame();
		automaticRoll(20, 0);
		g.scoreForTheGame();

		g.displayScore();
	}

	public static void allAreOnes() {
		g.emptyForNewGame();
		automaticRoll(20, 1);
		g.scoreForTheGame();

		g.displayScore();
	}

	public static void atleastOneSpare() {
		g.emptyForNewGame();
		spareGenerator();
		g.scoreForTheGame();

		g.displayScore();
	}

	public static void atleastOneStrike() {
		g.emptyForNewGame();
		strikeGenerator();
		g.scoreForTheGame();

		g.displayScore();
	}

	public static void thePerfectGame() {
		g.emptyForNewGame();
		automaticRoll(12, 10);
		g.scoreForTheGame();

		g.displayScore();
	}

	public static void theRandomGame() {
		g.emptyForNewGame();
		automaticRoll(4, 3);
		g.noOfPinsKnockedDownForEachBall(1);
		g.noOfPinsKnockedDownForEachBall(3);
		automaticRoll(4, 4);
		strikeGenerator();
		spareGenerator();
		g.noOfPinsKnockedDownForEachBall(7);
		g.noOfPinsKnockedDownForEachBall(1);

		g.scoreForTheGame();
		g.displayScore();
	}

}
